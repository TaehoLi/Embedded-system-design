/*********************************************************************
	Rhapsody	: 7.5.3 
	Login		: control
	Component	: CanButtonTest 
	Configuration 	: MontaVista
	Model Element	: MontaVista
//!	Generated Date	: Fri, 10, May 2019  
	File Path	: CanButtonTest/MontaVista/MainCanButtonTest.h
*********************************************************************/

#ifndef MainCanButtonTest_H
#define MainCanButtonTest_H

//## auto_generated
#include <oxf/oxf.h>
class CanButtonTest {
    ////    Constructors and destructors    ////
    
public :

    CanButtonTest();
};

#endif
/*********************************************************************
	File Path	: CanButtonTest/MontaVista/MainCanButtonTest.h
*********************************************************************/
